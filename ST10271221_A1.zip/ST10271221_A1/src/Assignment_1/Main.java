/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assignment_1;

/**
 *
 * @author brads
 */
public class Main extends StudentManagementApp {  
    public static void main(String[] args) throws Exception {
        StudentManagementApp sma = new StudentManagementApp();
        sma.Run();
        sma.displayMenu();
        sma.SaveStudent();
        sma.SearchStudent();
        sma.DeleteStudent();
        sma.StudentReport();
        sma.ExitApplication();
    }
}
