/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assignment_1;

/**
 *
 * @author brads
 */
public class Student { //Declaring variables needed.
    private int ID; 
    private String name;
    private int age;
    private String email;
    private String course;

    public int getID() { //Getter and Setter methods to access  student information.
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public Student(int ID, String name, int age, String email, String course) { // Constructor instantiates Student attributes. 
        this.ID = ID;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
    public void displayStudent() {
        System.out.println("STUDENT ID: " + ID);
        System.out.println("STUDENT NAME: " + name);
        System.out.println("STUDENT AGE: " + age);
        System.out.println("STUDENT EMAIL: " + email);
        System.out.println("STUDENT COURSE: " + course);
    }
}
