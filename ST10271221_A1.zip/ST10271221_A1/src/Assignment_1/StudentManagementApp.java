/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Assignment_1;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author brads
 */
public class StudentManagementApp {
    private ArrayList<Student> students = new ArrayList<>(); //created array list for student information
    private Scanner kb = new Scanner(System.in);//created scanner to recieve user input 
    
    //creating the methods
    
    public void Run() //this method displays the Menu 
    {
        while(true)
        {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("*************************************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = kb.nextLine();
            if (!choice.equals("1")) {
                System.out.println("Exiting application...");
                break;
            }
            displayMenu();
            
            int option = Integer.parseInt(kb.nextLine());

            switch (option) {
                case 1:
                    SaveStudent();
                    break;
                case 2:
                    SearchStudent();
                    break;
                case 3:
                    DeleteStudent();
                    break;
                case 4:
                    StudentReport();
                    break;
                case 5:
                    ExitApplication();
                    System.out.println("Exiting application...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
    
    public void displayMenu() 
    {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application.");
    }


    public void SaveStudent() { //creates student information
        System.out.println("\nCAPTURE A NEW STUDENT");
        System.out.println("***********************");
        System.out.print("Enter the student id: ");
        int id = kb.nextInt();
        kb.nextLine(); // Reads the newline character
        System.out.print("Enter the student name: ");
        String name = kb.nextLine();

        int age;
        do { //checking age validity 
            System.out.print("Enter the student age: ");
            age = kb.nextInt();
            if (age < 16) {
                System.out.println("You have entered an incorrect student age!!! \n Please re-enter the student age >>");
            }
        } while (age < 16);

        kb.nextLine(); // Reads the newline character
        System.out.print("Enter the student email: ");
        String email = kb.nextLine();
        System.out.print("Enter the student course: ");
        String course = kb.nextLine();
        Student student = new Student(id, name, age, email, course);
        students.add(student);
        System.out.println("Student details have been successfully saved.");
    }
    
    public void SearchStudent() // Search for Student information
    {
        System.out.print("Enter the student id to search: ");
        System.out.println("----------------------------------");
        int searchID = Integer.parseInt(kb.nextLine());

        for (Student student : students) {
            if (student.getID() == searchID) {
                System.out.println("STUDENT ID: " + student.getID());
                System.out.println("STUDENT NAME: " + student.getName());
                System.out.println("STUDENT AGE: " + student.getAge());
                System.out.println("STUDENT EMAIL: " + student.getEmail());
                System.out.println("STUDENT COURSE: " + student.getCourse());
                return;
            }
        }
        System.out.println("------------------------------------------------------------");
        System.out.println("Student with Student Id: " + searchID + " was not found!");
        System.out.println("------------------------------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        String choice = kb.nextLine();
        if (!choice.equals("1")) 
        {
            displayMenu();
        }
        else 
        {
            System.out.println("Exiting application...");
            System.exit(0);
        }     
    }
    
    public void DeleteStudent() // Search and delete student information
    {
        System.out.print("\n Enter the student ID to be deleted: ");
        int deleteID = kb.nextInt();

        for (int i = 0; i < students.size(); i++) 
        {
            if (students.get(i).getID() == deleteID) 
            {
                System.out.print("Are you sure? Press (Y) to confirm: ");
                System.out.println("------------------------------------------------------------");
                kb.nextLine(); 
                String confirm = kb.nextLine();
                if (confirm.equalsIgnoreCase("Y")) {
                    students.remove(i);
                    System.out.println("------------------------------------------------------------");
                    System.out.println("Student with Student Id: " + deleteID + " was deleted!");
                    System.out.println("------------------------------------------------------------");
                    System.out.println("Enter (1) to launch menu or any other key to exit");
                    String choice = kb.nextLine();
                    if (!choice.equals("1")) 
                    {
                        displayMenu();
                    }
                    else 
                    {
                        System.out.println("Exiting application...");
                        System.exit(0);
                    }   
                    return;
                }
            }
        }
        System.out.println("Student with Student Id: " + deleteID + " was not found!");
        System.out.println("------------------------------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        String choice = kb.nextLine();
        if (!choice.equals("1")) 
        {
            displayMenu();
        }
        else 
        {
            System.out.println("Exiting application...");
            System.exit(0);
        }   
    }
    
    public void StudentReport() // Displays the Student information in console
    {
        for (int i = 0; i < students.size(); i++) {
            System.out.println("STUDENT " + (i + 1));
            students.get(i).displayStudent();
        }
    }
    
    public void ExitApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}
