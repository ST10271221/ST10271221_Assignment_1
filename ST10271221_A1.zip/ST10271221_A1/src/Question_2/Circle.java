/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question_2;

/**
 *
 * @author brads
 */
public class Circle extends Shape {
// instance variable
private double radius;

    public Circle(String color, boolean fill, double radius) 
    {
        super(color, fill);
        this.radius = radius;
    }

    public Circle() 
    {
        
    }

    public double getRadius() 
    {
        return radius;
    }

    public void setRadius(double radius) 
    {
        this.radius = radius;
    }

    // This method returns the perimeter of the shape circle
    @Override
    public double perimeter() 
    {
        return 2 * Math.PI * radius;
    }

    // This method returns the  area of the shape circle
    @Override
    public double area() 
    {
        return Math.PI * radius * radius;
    }

// This method prints the shape details of Circle
@Override
    public void info() {
        System.out.println("Circle Color: " + getColor());
        System.out.println("Filled status: " + isFill());
        System.out.println("Circle Area: " + area());
        System.out.println("Circle Perimeter: " + perimeter());
    }
}

