/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question_2;

/**
 *
 * @author brads
 */
public class Rectangle extends Shape {
// instance variables
private double width;
private double height;

    public Rectangle(String color, boolean fill, double width, double height) 
    {
        super(color, fill);
        this.width = width;
        this.height = height;
    }

    public Rectangle() 
    {
        
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) 
    {
        this.width = width;
    }

    public double getHeight() 
    {
        return height;
    }

    public void setHeight(double height) 
    {
        this.height = height;
    }

    // This method return perimeter of the shape Rectangle
    @Override
    public double perimeter() 
    {
        return 2 * (width + height);
    }

    // This method returns area of the shape Rectangle
    @Override
    public double area() 
    {
        return width * height;
    }

    // This method prints the  shape of details for Rectangle
    @Override
    public void info() 
    {
        System.out.println("Rectangle Color: " + getColor());
        System.out.println("Filled status: " + isFill());
        System.out.println("Rectangle Area: " + area());
        System.out.println("Rectangle Perimeter: " + perimeter());

    }
}
