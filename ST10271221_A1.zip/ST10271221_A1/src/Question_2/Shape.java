/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question_2;

/**
 *
 * @author brads
 */
public class Shape 
{
    private String color;
    private boolean fill;

    public Shape(String color, boolean fill) 
    {
        this.color = color;
        this.fill = fill;
    }


    public Shape() 
    {
        
    }

    public String getColor() 
    {
        return color;
    }


    public void setColor(String color) {
        this.color = color;
    }


    public boolean isFill() 
    {
        return fill;
    }


    public void setFill(boolean fill)
    {
        this.fill = fill;
    }

    // This method return perimeter of the shape
    public double perimeter() 
    {
        return 0;
    }

    // This method return area of the shape
    public double area() 
    {
        return 0;
    }

    // This method print shape details
    public void info() {
        System.out.println("Shape Color: " + getColor());
        System.out.println("Filled status: " + isFill());
    }
}

