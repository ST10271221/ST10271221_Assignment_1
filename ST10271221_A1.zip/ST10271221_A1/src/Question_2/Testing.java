/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question_2;

/**
 *
 * @author brads
 */
public class Testing {

    public static void main(String[] args) 
    {
        // Create an Shape array
        Shape[] shapes = new Shape[2];
        
        // Create an object of Circle
        Circle circle = new Circle("RED", true, 5);
        
        // Create an object of Rectangle
        Rectangle rectangle = new Rectangle("Blue", false, 3, 2);
        
        // add instances to an array
        shapes[0] = circle;
        shapes[1] = rectangle;

        // loop array and print details of each shape
        for (int i = 0; i < shapes.length; i++) 
        {
            shapes[i].info();
            System.out.println();
        }
    }
}
